from django.conf.urls import url
from django.contrib.auth import views as auth_views
from nistserver import views
from django.views.generic import RedirectView

urlpatterns = [
    url(r'^$', auth_views.login),
	url(r'^index.html', auth_views.login),
	url(r'^logout/$', auth_views.logout, {'next_page': '/'}, name='logout'),
	url(r'^logout.html', auth_views.logout, {'next_page': '/'}, name='logout'),
	url(r'^home.html',views.homepage.as_view()),
    url(r'^overview1.html',views.MANO.as_view()),
    url(r'^overview2.html',views.VNF.as_view()),
    url(r'^overview3.html',views.NFVI.as_view()),
    url(r'^overview4.html',views.HWR.as_view()),
    url(r'^analysis.html',views.analysis.as_view()),
    url(r'^audit.html',RedirectView.as_view(url="http://192.168.0.74:8000/")),
    url(r'^hardening.html',views.analysis.as_view()),
    url(r'^logmon.html',RedirectView.as_view(url="http://192.168.0.74:8200/")),
    url(r'^cred.html',RedirectView.as_view(url="https://192.168.0.90:8200/")),
    url(r'^Maas.html',RedirectView.as_view(url="http://192.168.0.210:9082/maas")),
    url(r'^policy.html',views.analysis.as_view()),
    url(r'^assurance.html',views.analysis.as_view()),
    url(r'^controls.html',views.analysis.as_view()),
    url(r'^storage.html',views.analysis.as_view()),
    url(r'^ident.html',views.analysis.as_view()),
    
]