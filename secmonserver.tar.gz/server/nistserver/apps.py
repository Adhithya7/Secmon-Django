from django.apps import AppConfig


class NistserverConfig(AppConfig):
    name = 'nistserver'
