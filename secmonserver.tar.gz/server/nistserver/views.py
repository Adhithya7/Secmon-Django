import os

from django.shortcuts import render
from django.views.generic import TemplateView
from itertools import islice
from django.http import HttpResponseRedirect

homedir = os.environ['HOME']
template_path = homedir + '/secmon/smon/server/nistserver/templates/'

class homepage(TemplateView):
    def get(self,request):
        if request.user.is_authenticated:
            return render(request,'home.html')
        else :
            return HttpResponseRedirect('logout.html')

class MANO(TemplateView):
    template_name="overview1.html"

class VNF(TemplateView):
    template_name="overview2.html"

class NFVI(TemplateView):
    template_name="overview3.html"

class HWR(TemplateView):
    template_name="overview4.html"

class analysis(TemplateView):
    template_name="analysis.html"